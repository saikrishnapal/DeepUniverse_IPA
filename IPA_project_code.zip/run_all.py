"""Runs every experiment of the project and writes figures + results.json to ./results"""
import os, json, time
import numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import ndimage as ndi
from scipy.fft import dctn
from skimage import data, color, exposure, filters, feature, measure, transform
from sklearn.cluster import KMeans
from ipa_core import *

OUT = 'results'; os.makedirs(OUT, exist_ok=True)
R = {}; rng = np.random.default_rng(2026)
t0 = time.time()

def rs(img, n=256):
    return np.clip(np.rint(transform.resize(img, (n, n), anti_aliasing=True, preserve_range=True)), 0, 255).astype(np.uint8)

moon = rs(data.moon())
hf = data.hubble_deep_field(); s = min(hf.shape[:2]); y0, x0 = (hf.shape[0] - s) // 2, (hf.shape[1] - s) // 2
hub = rs(hf[y0:y0 + s, x0:x0 + s])
hubg = u8(color.rgb2gray(hub) * 255)
cam = rs(data.camera())
Image_ = __import__('PIL.Image', fromlist=['Image'])
Image_.fromarray(moon).save(f'{OUT}/moon.png'); Image_.fromarray(hub).save(f'{OUT}/hubble.png')

def grid(imgs, titles, ncols, name, size=2.0, rowh=1.12):
    n = len(imgs); nr = (n + ncols - 1) // ncols
    fig, axs = plt.subplots(nr, ncols, figsize=(ncols * size, nr * size * rowh))
    axs = np.atleast_1d(axs).ravel()
    for ax in axs: ax.axis('off')
    for ax, im, t in zip(axs, imgs, titles):
        ax.imshow(im, cmap='gray', vmin=0, vmax=255) if im.ndim == 2 else ax.imshow(im)
        ax.set_title(t, fontsize=7)
    plt.tight_layout(pad=0.4); fig.savefig(f'{OUT}/{name}.png', dpi=170); plt.close(fig)

# ---------------------------------------------------------------- unit tests
tests = []
def T(name, ok): tests.append((name, bool(ok)))
a = moon[:64, :64]
T('conv2d equals scipy.ndimage.convolve', np.allclose(conv2d(a, gauss_kernel(5, 1)), ndi.convolve(a.astype(float), gauss_kernel(5, 1), mode='mirror')))
T('median filter equals scipy', np.array_equal(median_filter(a, 3), ndi.median_filter(a, 3, mode='mirror')))
T('DCT matrix matches scipy dctn (orthonormal)', np.allclose(C8 @ (a[:8, :8] - 128.0) @ C8.T, dctn(a[:8, :8] - 128.0, norm='ortho')))
T('zigzag scan is invertible', np.array_equal(np.arange(64)[ZZ][ZZ_INV], np.arange(64)))
T('Otsu threshold equals scikit-image', otsu(moon) == filters.threshold_otsu(moon))
T('identity frequency filter returns the image', np.allclose(freq_filter(a, np.ones((64, 64))), a))
ramp = np.tile(np.arange(256, dtype=np.uint8), (4, 1)); T('histogram equalisation mapping is monotone', np.all(np.diff(hist_eq(ramp)[0].astype(int)) >= 0))
fr = Counter(np.random.default_rng(1).integers(0, 40, 5000).tolist()); cd = canonical_codes(huffman_lengths(fr)); cs = list(cd.values())
T('Huffman code is prefix-free', all(not (x != y and y.startswith(x)) for x in cs for y in cs))
rt = codec(hub, 50, verify=True)
T('entropy-coding stage is lossless (encode then decode)', rt['lossless_ok'])
T('YCbCr round trip error below 1 grey level', np.abs(ycbcr2rgb(*rgb2ycbcr(hub)).astype(int) - hub).max() <= 1)
T('PSNR of identical images is capped', psnr(hub, hub) == 99.0)
R['tests'] = [(n, ok) for n, ok in tests]

# ------------------------------------------------------------------ Part 1
imgs = [moon] + [sample(moon, k) for k in (2, 4, 8)]
tit = ['Original'] + [f'Sampled /{k}' for k in (2, 4, 8)]
imgs += [requantize(moon, L) for L in (64, 16, 4, 2)]
tit += [f'{int(np.log2(L))}-bit ({L} levels)' for L in (64, 16, 4, 2)]
grid(imgs, tit, 4, 'fig_sampling')
R['p1'] = {'sample': {k: psnr(moon, sample(moon, k)) for k in (2, 4, 8)},
           'quant': {L: psnr(moon, requantize(moon, L)) for L in (64, 16, 4, 2)}}

# ------------------------------------------------------------------ Part 2
low = u8(100 + (moon.astype(float) - moon.min()) * (60.0 / (moon.max() - moon.min())))
ref_hist = cam
en = {'Low-contrast input': low, 'Negative': negative(low), 'Log transform': log_tx(low),
      'Gamma 0.6': gamma_tx(low, 0.6), 'Contrast stretch': contrast_stretch(low),
      'Histogram equalisation': hist_eq(low), 'Histogram specification': hist_spec(low, ref_hist),
      'CLAHE': u8(255 * exposure.equalize_adapthist(low, clip_limit=0.02))}
R['p2'] = {k: dict(entropy=entropy(v), std=float(v.std()), psnr=psnr(moon, v)) for k, v in en.items()}
R['p2']['Original moon'] = dict(entropy=entropy(moon), std=float(moon.std()), psnr=99.0)
grid([moon, low, en['Contrast stretch'], en['Histogram equalisation'], en['CLAHE'], en['Gamma 0.6'], en['Histogram specification'], en['Log transform']],
     ['Original', 'Low contrast', 'Contrast stretch', 'Hist. equalisation', 'CLAHE', 'Gamma 0.6', 'Hist. specification', 'Log transform'], 4, 'fig_enhance')
fig, ax = plt.subplots(1, 4, figsize=(8.6, 1.9))
for a_, (t_, im) in zip(ax, [('Low contrast', low), ('Equalised', en['Histogram equalisation']), ('CLAHE', en['CLAHE']), ('Stretched', en['Contrast stretch'])]):
    a_.hist(im.ravel(), 64, range=(0, 255), color='#1f5f7a'); a_.set_title(t_, fontsize=7); a_.tick_params(labelsize=6)
plt.tight_layout(); fig.savefig(f'{OUT}/fig_hist.png', dpi=170); plt.close(fig)

# denoising
sp = salt_pepper(moon, 0.05, rng); gn = u8(moon + rng.normal(0, 20, moon.shape))
den = {}
for nm, noisy in (('Salt-and-pepper 5%', sp), ('Gaussian sigma=20', gn)):
    den[nm] = {'Noisy image': psnr(moon, noisy), 'Box 3x3': psnr(moon, u8(conv2d(noisy, box_kernel(3)))),
               'Gaussian 5x5': psnr(moon, u8(conv2d(noisy, gauss_kernel(5, 1.0)))), 'Median 3x3': psnr(moon, median_filter(noisy, 3))}
R['p2_den'] = den
grid([sp, u8(conv2d(sp, box_kernel(3))), u8(conv2d(sp, gauss_kernel(5, 1.0))), median_filter(sp, 3),
      gn, u8(conv2d(gn, box_kernel(3))), u8(conv2d(gn, gauss_kernel(5, 1.0))), median_filter(gn, 3)],
     ['Salt & pepper 5%', 'Box 3x3', 'Gaussian 5x5', 'Median 3x3', 'Gaussian noise s=20', 'Box 3x3', 'Gaussian 5x5', 'Median 3x3'], 4, 'fig_denoise')
bl = conv2d(moon, gauss_kernel(5, 1.0))
sh = {'Original': moon, 'Laplacian sharpen': u8(moon + conv2d(moon, LAPLACIAN)), 'Unsharp mask': u8(moon + (moon - bl)),
      'High-boost k=2.5': u8(moon + 2.5 * (moon - bl))}
R['p2_sharp'] = {k: float(ndi.laplace(v.astype(float)).var()) for k, v in sh.items()}
grid(list(sh.values()), list(sh.keys()), 4, 'fig_sharpen')

# ------------------------------------------------------------------ Part 3
sp_img = fft_spectrum(moon)
filt = {'Gaussian LPF D0=10': glpf(moon.shape, 10), 'Gaussian LPF D0=30': glpf(moon.shape, 30), 'Gaussian LPF D0=60': glpf(moon.shape, 60),
        'Ideal LPF D0=30': ilpf(moon.shape, 30), 'Butterworth LPF D0=30': blpf(moon.shape, 30)}
fo = {k: u8(freq_filter(moon, H)) for k, H in filt.items()}
R['p3_lp'] = {k: psnr(moon, v) for k, v in fo.items()}
hp = {'Gaussian HPF D0=30': 1 - glpf(moon.shape, 30), 'Butterworth HPF D0=30': 1 - blpf(moon.shape, 30)}
ho = {k: freq_filter(moon, H) for k, H in hp.items()}
ho = {k: u8(255 * (v - v.min()) / (v.max() - v.min())) for k, v in ho.items()}
hfe = u8(freq_filter(moon, 0.5 + 1.5 * (1 - glpf(moon.shape, 30))))
grid([moon, sp_img] + list(fo.values()) + list(ho.values()) + [hfe],
     ['Original', 'Log spectrum'] + list(fo.keys()) + list(ho.keys()) + ['High-frequency emphasis'], 5, 'fig_freq', size=1.75)
# homomorphic on uneven illumination
illum = np.tile(np.linspace(0.25, 1.0, 256), (256, 1))
uneven = u8(moon * illum)
hm = homomorphic(uneven, 30, 0.5, 1.8)
def illum_var(im): return float(ndi.gaussian_filter(im.astype(float), 25).std())
R['p3_homo'] = {'uneven_std_local_mean': illum_var(uneven), 'homo_std_local_mean': illum_var(hm),
                'uneven_ratio': float(illum_var(uneven) / uneven.mean()), 'homo_ratio': float(illum_var(hm) / hm.mean())}
# periodic noise + notch
X, Y = np.meshgrid(np.arange(256), np.arange(256))
per = u8(moon + 35 * np.sin(2 * np.pi * (30 * X + 20 * Y) / 256))
notched = u8(freq_filter(per, notch_reject((256, 256), [(20, 30)], 4)))
R['p3_notch'] = {'noisy': psnr(moon, per), 'notch': psnr(moon, notched)}
grid([uneven, hm, per, fft_spectrum(per), notched], ['Uneven illumination', 'Homomorphic filter', 'Periodic noise', 'Spectrum (spikes)', 'Notch-filtered'], 5, 'fig_homo', size=1.75)

# ------------------------------------------------------------------ Part 4
H = psf2otf(gauss_kernel(15, 3), moon.shape)
sigmas = [0, 2, 5, 10, 20]; Ks = [1e-4, 3e-4, 1e-3, 3e-3, 1e-2, 3e-2, 1e-1, 3e-1]
tab = []; demo = None; var_f = float(moon.astype(float).var())
for sg in sigmas:
    g = degrade(moon, H, sg, np.random.default_rng(100 + sg))
    inv = inverse_filter(g, H, 1e-3)
    bestK = max(Ks, key=lambda k: psnr(moon, wiener_filter(g, H, k))); wi = wiener_filter(g, H, bestK)
    bestG = max(Ks, key=lambda k: psnr(moon, cls_filter(g, H, k))); cl = cls_filter(g, H, bestG)
    Kest = max(sg ** 2 / var_f, 1e-4); we = wiener_filter(g, H, Kest)
    thrs = [1e-3, 3e-3, 1e-2, 3e-2, 1e-1, 3e-1]; bestT = max(thrs, key=lambda t: psnr(moon, inverse_filter(g, H, t))); invb = inverse_filter(g, H, bestT)
    tab.append(dict(sigma=sg, degraded=psnr(moon, g), inverse=psnr(moon, inv), wiener=psnr(moon, wi), cls=psnr(moon, cl),
                    wiener_est=psnr(moon, we), inverse_best=psnr(moon, invb), thr_best=bestT, K=bestK, gamma=bestG, Kest=Kest))
    if sg == 5: demo = [moon, g, inv, wi, cl]
R['p4'] = tab
grid(demo, ['Original', 'Blur + noise (s=5)', 'Inverse filter', 'Wiener', 'CLS'], 5, 'fig_restore', size=1.75)
fig, ax = plt.subplots(figsize=(4.6, 3.1))
for key, lab in (('degraded', 'Degraded'), ('inverse', 'Inverse (thr=1e-3)'), ('wiener', 'Wiener (best K)'), ('cls', 'CLS (best gamma)')):
    ax.plot(sigmas, [r[key] for r in tab], 'o-', label=lab, ms=4)
ax.set_xlabel('Noise sigma'); ax.set_ylabel('PSNR (dB)'); ax.grid(alpha=.3); ax.legend(fontsize=7); ax.set_title('Restoration vs noise level', fontsize=9)
plt.tight_layout(); fig.savefig(f'{OUT}/fig_restore_plot.png', dpi=170); plt.close(fig)
mpsf = motion_psf(21, 30); Hm = psf2otf(mpsf, moon.shape); gm = degrade(moon, Hm, 1, np.random.default_rng(7))
mi = inverse_filter(gm, Hm, 1e-2); mw = wiener_filter(gm, Hm, 0.01)
R['p4_motion'] = dict(degraded=psnr(moon, gm), inverse=psnr(moon, mi), wiener=psnr(moon, mw))
grid([moon, gm, mi, mw], ['Original', 'Motion blur (21px, 30 deg)', 'Inverse filter', 'Wiener K=0.01'], 4, 'fig_motion')

# ------------------------------------------------------------------ Part 5
y_, cb_, cr_ = rgb2ycbcr(hub); hsv = color.rgb2hsv(hub)
pseudo = (plt.get_cmap('jet')(hubg / 255.0)[..., :3] * 255).astype(np.uint8)
hsv_eq = hsv.copy(); hsv_eq[..., 2] = hist_eq(u8(hsv[..., 2] * 255)) / 255.0; hub_eq = u8(color.hsv2rgb(hsv_eq) * 255)
grid([hub, u8(y_), u8(cb_), u8(cr_), 255 - hub, u8(hsv[..., 0] * 255), u8(hsv[..., 1] * 255), pseudo, hub_eq, hubg],
     ['RGB', 'Y', 'Cb', 'Cr', 'CMY', 'H', 'S', 'Pseudo-colour (jet)', 'V-channel equalised', 'Grayscale'], 5, 'fig_color', size=1.75)
R['p5_color'] = dict(entropy_gray=entropy(hubg), entropy_eq=entropy(u8(color.rgb2gray(hub_eq) * 255)))
qs = [5, 10, 20, 30, 50, 70, 90]; comp = []
for q in qs:
    c1 = codec(hub, q, verify=(q in (10, 50, 90))); p1 = pillow_jpeg(hub, q); p2 = pillow_jpeg(hub, q, optimize=True)
    comp.append(dict(q=q, bpp=c1['bpp'], ratio=c1['ratio'], psnr=c1['psnr'], ssim=c1['ssim'], payload=c1['payload'], header=c1['header'],
                     p_bpp=p1['bpp'], p_ratio=p1['ratio'], p_psnr=p1['psnr'], p_ssim=p1['ssim'], po_ratio=p2['ratio'], po_psnr=p2['psnr'], ok=c1['lossless_ok']))
    if q in (10, 30, 50, 90): globals()[f'dec{q}'] = c1['recon']
R['p5'] = comp
grid([hub, dec10, dec30, dec50, dec90], ['Original'] + [f'Q={q}  {[c for c in comp if c["q"] == q][0]["ratio"]:.1f}:1' for q in (10, 30, 50, 90)], 5, 'fig_decoded', size=1.75)
# zoomed blocking view
crop = (slice(60, 108), slice(60, 108))
grid([hub[crop], dec10[crop], dec50[crop]], ['Original (zoom)', 'Q=10', 'Q=50'], 3, 'fig_zoom', size=2.0)
fig, ax = plt.subplots(figsize=(4.6, 3.1))
ax.plot([c['ratio'] for c in comp], [c['psnr'] for c in comp], 'o-', label='Project codec', ms=4)
ax.plot([c['p_ratio'] for c in comp], [c['p_psnr'] for c in comp], 's-', label='Pillow JPEG', ms=4)
ax.plot([c['po_ratio'] for c in comp], [c['po_psnr'] for c in comp], '^-', label='Pillow JPEG (optimised Huffman)', ms=4)
ax.set_xlabel('Compression ratio'); ax.set_ylabel('PSNR (dB)'); ax.grid(alpha=.3); ax.legend(fontsize=7); ax.set_title('Rate-distortion (colour)', fontsize=9)
plt.tight_layout(); fig.savefig(f'{OUT}/fig_rd.png', dpi=170); plt.close(fig)
fig, ax = plt.subplots(figsize=(4.6, 3.1))
ax.plot(qs, [c['ratio'] for c in comp], 'o-', label='Project codec', ms=4); ax.plot(qs, [c['p_ratio'] for c in comp], 's-', label='Pillow JPEG', ms=4)
ax.set_xlabel('Quality factor'); ax.set_ylabel('Compression ratio'); ax.grid(alpha=.3); ax.legend(fontsize=7); ax.set_title('Compression ratio vs quality', fontsize=9)
plt.tight_layout(); fig.savefig(f'{OUT}/fig_ratio.png', dpi=170); plt.close(fig)
c50 = [c for c in comp if c['q'] == 50][0]; ns = codec(hub, 50, subsample=False)
yq = codec(hubg, 50)
R['p5_extra'] = dict(sub_ratio=c50['ratio'], sub_psnr=c50['psnr'], nosub_ratio=ns['ratio'], nosub_psnr=ns['psnr'],
                     gray_entropy=entropy(hubg), gray_bpp=yq['bpp'], gray_payload_bpp=yq['payload'] / hubg.size, gray_ratio=yq['ratio'])

# ------------------------------------------------------------------ Part 6
sob = gradient_mag(moon, SOBEL_X); pre = gradient_mag(moon, PREWITT_X)
def bin_mag(m): return m > filters.threshold_otsu(m)
canny = lambda im: feature.canny(im, sigma=1.5, low_threshold=0.80, high_threshold=0.92, use_quantiles=True)
cn = canny(moon)
R['p6_edge_density'] = dict(sobel=float(bin_mag(sob).mean()), prewitt=float(bin_mag(pre).mean()), canny=float(cn.mean()))
cdec = {}; edge_tab = []; edge_imgs = []
for q in (10, 50, 90):
    cc = codec(moon, q); pp = pillow_jpeg(moon, q)
    for nm, r_ in (('Project', cc), ('Pillow', pp)):
        e = canny(r_['recon']); m = confusion_metrics(cn, e)
        m.update(codec=nm, q=q, psnr=r_['psnr'], f1tol=edge_f1_tol(cn, e, 1)); edge_tab.append(m)
        if nm == 'Project': edge_imgs.append((q, cc['recon'], e))
R['p6_edge'] = edge_tab
imgs = [moon, u8(255 * bin_mag(sob)), u8(255 * bin_mag(pre)), u8(255 * cn)]; tit = ['Original', 'Sobel', 'Prewitt', 'Canny']
for q, d, e in edge_imgs: imgs += [d, u8(255 * e)]; tit += [f'Decoded Q={q}', f'Canny on Q={q}']
grid(imgs, tit, 4, 'fig_edges', size=1.9)
# segmentation and morphology (Hubble gray: bright objects on dark sky)
T_ = otsu(hubg); mask = hubg > T_
mask_c = closing(opening(mask)); seed = (5, 5)
rg = region_grow(hubg, seed, 12)
km = KMeans(3, n_init=10, random_state=0).fit(moon.reshape(-1, 1).astype(float))
kmi = u8(km.cluster_centers_[km.labels_].reshape(moon.shape))
kc = KMeans(4, n_init=10, random_state=0).fit(hub.reshape(-1, 3).astype(float)); kci = u8(kc.cluster_centers_[kc.labels_].reshape(hub.shape))
grid([hubg, u8(255 * mask), u8(255 * mask_c), u8(255 * dilate(mask)), u8(255 * erode(mask)), u8(255 * rg), kmi, kci],
     ['Hubble gray', f'Otsu T={T_}', 'Opening + closing', 'Dilation', 'Erosion', 'Region growing (sky seed)', 'K-means (k=3, Moon gray)', 'K-means (k=4, Hubble colour)'], 4, 'fig_seg', size=1.9)
R['p6_seg'] = dict(otsu=T_, fg_frac=float(mask.mean()), rg_frac=float(rg.mean()), km_centers=sorted(km.cluster_centers_.ravel().round(1).tolist()),
                   kc_centers=[[int(v) for v in c] for c in kc.cluster_centers_.round()],
                   n_before=int(measure.label(mask).max()), n_after=int(measure.label(mask_c).max()))

# ------------------------------------------------------------------ Part 7: features + application
lab = measure.label(mask_c, connectivity=1); props = sorted(measure.regionprops(lab), key=lambda p: -p.area)[:6]
R['p7_regions'] = [dict(area=int(p.area), perim=float(p.perimeter), cy=float(p.centroid[0]), cx=float(p.centroid[1]), ecc=float(p.eccentricity), sol=float(p.solidity)) for p in props]
def texture(img):
    g = feature.graycomatrix(img // 4, [1], [0, np.pi / 4, np.pi / 2, 3 * np.pi / 4], levels=64, symmetric=True, normed=True)
    d = {k: float(feature.graycoprops(g, k).mean()) for k in ('contrast', 'homogeneity', 'energy', 'correlation')}
    lbp = feature.local_binary_pattern(img, 8, 1, 'uniform'); h_ = np.bincount(lbp.astype(int).ravel(), minlength=10) / lbp.size
    d['lbp_entropy'] = float(-(h_[h_ > 0] * np.log2(h_[h_ > 0])).sum()); return d
R['p7_tex'] = {'Moon surface': texture(moon), 'Hubble (gray)': texture(hubg)}
# application: counting objects in Hubble deep field, with and without enhancement
def count_objects(g, k=2.0, minarea=3):
    sm = ndi.gaussian_filter(g.astype(float), 1.0); thr = sm.mean() + k * sm.std()
    lb = measure.label(sm > thr, connectivity=2); ps = [p for p in measure.regionprops(lb, intensity_image=g) if p.area >= minarea]
    return lb, ps, thr
lb0, ps0, th0 = count_objects(hubg, 2.0)
enh = u8(255 * exposure.equalize_adapthist(hubg, clip_limit=0.02)); gam = gamma_tx(hubg, 0.5)
lb1, ps1, th1 = count_objects(gam, 1.0)
R['p7_app'] = dict(n_raw=len(ps0), thr_raw=float(th0), n_gamma=len(ps1), thr_gamma=float(th1),
                   mean_area_raw=float(np.mean([p.area for p in ps0])), max_area_raw=int(max(p.area for p in ps0)),
                   ecc_round=int(sum(p.eccentricity < 0.6 for p in ps0)), ecc_elong=int(sum(p.eccentricity >= 0.6 for p in ps0)))
fig, axs = plt.subplots(1, 3, figsize=(8.6, 3.0))
axs[0].imshow(hub); axs[0].set_title('Hubble Deep Field (input)', fontsize=7)
axs[1].imshow(hubg, cmap='gray'); axs[1].set_title(f'Detected objects: {len(ps0)} (raw, k=2)', fontsize=7)
for p in ps0: axs[1].plot(p.centroid[1], p.centroid[0], 'r+', ms=3, mew=0.5)
axs[2].imshow(gam, cmap='gray'); axs[2].set_title(f'After gamma 0.5: {len(ps1)} objects (k=1)', fontsize=7)
for p in ps1: axs[2].plot(p.centroid[1], p.centroid[0], 'c+', ms=3, mew=0.5)
for a_ in axs: a_.axis('off')
plt.tight_layout(); fig.savefig(f'{OUT}/fig_app.png', dpi=170); plt.close(fig)
fig, ax = plt.subplots(figsize=(4.4, 2.6))
ax.hist([p.area for p in ps0], bins=np.logspace(0.4, 3, 18)); ax.set_xscale('log'); ax.set_xlabel('Object area (pixels)'); ax.set_ylabel('Count'); ax.set_title('Size distribution of detected objects', fontsize=8); ax.grid(alpha=.3)
plt.tight_layout(); fig.savefig(f'{OUT}/fig_areahist.png', dpi=170); plt.close(fig)

R['runtime_s'] = time.time() - t0
json.dump(R, open(f'{OUT}/results.json', 'w'), indent=1, default=float)
print('done', round(R['runtime_s'], 1), 's;', sum(ok for _, ok in tests), '/', len(tests), 'tests passed')
