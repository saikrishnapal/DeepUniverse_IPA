"""Core digital image processing routines (written from scratch with NumPy).
Units: fundamentals, enhancement, frequency domain, restoration, colour,
JPEG-style compression, morphology/segmentation, metrics."""
import heapq, io
from collections import Counter, deque
import numpy as np
from scipy import ndimage as ndi
from skimage.metrics import structural_similarity as _ssim
from PIL import Image

# ------------------------------------------------------------------ metrics
def u8(a):
    return np.clip(np.rint(a), 0, 255).astype(np.uint8)

def mse(a, b):
    return float(np.mean((a.astype(float) - b.astype(float)) ** 2))

def psnr(a, b):
    m = mse(a, b)
    return 99.0 if m == 0 else float(10 * np.log10(255.0 ** 2 / m))

def ssim(a, b):
    return float(_ssim(a, b, data_range=255, channel_axis=-1 if a.ndim == 3 else None))

def entropy(a):
    p = np.bincount(a.ravel(), minlength=256) / a.size
    p = p[p > 0]
    return float(-(p * np.log2(p)).sum())

def confusion_metrics(ref, test):
    ref = ref.astype(bool); test = test.astype(bool)
    TP = int((ref & test).sum()); TN = int((~ref & ~test).sum())
    FP = int((~ref & test).sum()); FN = int((ref & ~test).sum())
    n = TP + TN + FP + FN
    acc = (TP + TN) / n
    sens = TP / (TP + FN) if TP + FN else 0.0
    spec = TN / (TN + FP) if TN + FP else 0.0
    prec = TP / (TP + FP) if TP + FP else 0.0
    f1 = 2 * prec * sens / (prec + sens) if prec + sens else 0.0
    pe = ((TP + FP) * (TP + FN) + (TN + FN) * (TN + FP)) / n ** 2
    kappa = (acc - pe) / (1 - pe) if pe != 1 else 1.0
    return dict(acc=acc, sens=sens, spec=spec, prec=prec, f1=f1, kappa=kappa)

def edge_f1_tol(ref, test, tol=1):
    """F1 of two edge maps with a pixel tolerance."""
    k = np.ones((2 * tol + 1, 2 * tol + 1), bool)
    rd = ndi.binary_dilation(ref, k); td = ndi.binary_dilation(test, k)
    prec = (test & rd).sum() / max(test.sum(), 1)
    rec = (ref & td).sum() / max(ref.sum(), 1)
    return float(2 * prec * rec / (prec + rec)) if prec + rec else 0.0

# ------------------------------------------------------------ fundamentals
def sample(img, k):
    s = img[::k, ::k]
    return np.kron(s, np.ones((k, k), np.uint8))

def requantize(img, L):
    step = 256 / L
    return np.clip(np.floor(img / step) * (255 / (L - 1)), 0, 255).astype(np.uint8)

# ------------------------------------------------------------- enhancement
def negative(a): return 255 - a
def log_tx(a):
    c = 255 / np.log(1 + a.max()); return u8(c * np.log(1 + a.astype(float)))
def gamma_tx(a, g): return u8(255 * (a / 255.0) ** g)
def contrast_stretch(a):
    lo, hi = float(a.min()), float(a.max()); return u8(255 * (a - lo) / (hi - lo))

def hist_eq(img):
    h = np.bincount(img.ravel(), minlength=256); cdf = h.cumsum()
    cmin = cdf[cdf > 0].min()
    lut = np.clip(np.rint(255 * (cdf - cmin) / (img.size - cmin)), 0, 255).astype(np.uint8)
    return lut[img]

def hist_spec(img, ref):
    cs = np.bincount(img.ravel(), minlength=256).cumsum() / img.size
    cr = np.bincount(ref.ravel(), minlength=256).cumsum() / ref.size
    return np.clip(np.searchsorted(cr, cs), 0, 255).astype(np.uint8)[img]

def conv2d(img, k):
    k = np.asarray(k, float); kh, kw = k.shape; ph, pw = kh // 2, kw // 2
    p = np.pad(img.astype(float), ((ph, ph), (pw, pw)), mode='reflect')
    kf = k[::-1, ::-1]; out = np.zeros(img.shape, float)
    for i in range(kh):
        for j in range(kw):
            out += kf[i, j] * p[i:i + img.shape[0], j:j + img.shape[1]]
    return out

def median_filter(img, k=3):
    p = np.pad(img, k // 2, mode='reflect')
    win = np.lib.stride_tricks.sliding_window_view(p, (k, k))
    return np.median(win, axis=(2, 3)).astype(np.uint8)

def gauss_kernel(size, sigma):
    ax = np.arange(size) - size // 2; g = np.exp(-ax ** 2 / (2.0 * sigma ** 2))
    k = np.outer(g, g); return k / k.sum()

def box_kernel(n): return np.ones((n, n)) / (n * n)
LAPLACIAN = np.array([[0, -1, 0], [-1, 4, -1], [0, -1, 0]], float)

def salt_pepper(img, frac, rng):
    out = img.copy(); r = rng.random(img.shape)
    out[r < frac / 2] = 0; out[(r >= frac / 2) & (r < frac)] = 255
    return out

# ----------------------------------------------------------- frequency domain
def fft_spectrum(img):
    F = np.fft.fftshift(np.fft.fft2(img.astype(float)))
    s = np.log1p(np.abs(F)); return u8(255 * s / s.max())

def dist_grid(shape):
    u = np.arange(shape[0]) - shape[0] // 2; v = np.arange(shape[1]) - shape[1] // 2
    return np.sqrt(u[:, None] ** 2 + v[None, :] ** 2)

def ilpf(shape, d0): return (dist_grid(shape) <= d0).astype(float)
def blpf(shape, d0, n=2): return 1 / (1 + (dist_grid(shape) / d0) ** (2 * n))
def glpf(shape, d0): return np.exp(-dist_grid(shape) ** 2 / (2.0 * d0 ** 2))

def freq_filter(img, H):
    F = np.fft.fftshift(np.fft.fft2(img.astype(float)))
    return np.real(np.fft.ifft2(np.fft.ifftshift(F * H)))

def homomorphic(img, d0=30, gl=0.5, gh=1.8, c=1.0):
    D2 = dist_grid(img.shape) ** 2
    H = (gh - gl) * (1 - np.exp(-c * D2 / d0 ** 2)) + gl
    out = np.exp(freq_filter(np.log1p(img.astype(float)), H)) - 1
    return u8(255 * (out - out.min()) / (out.max() - out.min()))

def notch_reject(shape, points, sigma=4):
    cy, cx = shape[0] // 2, shape[1] // 2
    yy, xx = np.mgrid[:shape[0], :shape[1]]; H = np.ones(shape)
    for (dy, dx) in points:
        for s in (1, -1):
            H -= np.exp(-((yy - (cy + s * dy)) ** 2 + (xx - (cx + s * dx)) ** 2) / (2.0 * sigma ** 2))
    return np.clip(H, 0, 1)

# -------------------------------------------------------------- restoration
def psf2otf(psf, shape):
    big = np.zeros(shape); h, w = psf.shape; big[:h, :w] = psf
    big = np.roll(big, (-(h // 2), -(w // 2)), (0, 1)); return np.fft.fft2(big)

def degrade(img, H, sigma, rng):
    g = np.real(np.fft.ifft2(np.fft.fft2(img.astype(float)) * H))
    if sigma > 0: g = g + rng.normal(0, sigma, img.shape)
    return u8(g)

def inverse_filter(g, H, thr=1e-3):
    G = np.fft.fft2(g.astype(float)); Hs = np.where(np.abs(H) > thr, H, 1)
    F = np.where(np.abs(H) > thr, G / Hs, 0)
    return u8(np.real(np.fft.ifft2(F)))

def wiener_filter(g, H, K):
    G = np.fft.fft2(g.astype(float))
    return u8(np.real(np.fft.ifft2(np.conj(H) * G / (np.abs(H) ** 2 + K))))

def cls_filter(g, H, gamma):
    G = np.fft.fft2(g.astype(float)); P = psf2otf(LAPLACIAN, g.shape)
    return u8(np.real(np.fft.ifft2(np.conj(H) * G / (np.abs(H) ** 2 + gamma * np.abs(P) ** 2))))

def motion_psf(length, angle):
    psf = np.zeros((length, length)); c = length // 2; t = np.deg2rad(angle)
    for s in np.linspace(-c, c, 4 * length):
        psf[int(round(c - s * np.sin(t))), int(round(c + s * np.cos(t)))] = 1
    return psf / psf.sum()

# ------------------------------------------------------------------- colour
def rgb2ycbcr(rgb):
    r, g, b = [rgb[..., i].astype(float) for i in range(3)]
    y = 0.299 * r + 0.587 * g + 0.114 * b
    cb = -0.168736 * r - 0.331264 * g + 0.5 * b + 128
    cr = 0.5 * r - 0.418688 * g - 0.081312 * b + 128
    return y, cb, cr

def ycbcr2rgb(y, cb, cr):
    r = y + 1.402 * (cr - 128); g = y - 0.344136 * (cb - 128) - 0.714136 * (cr - 128)
    b = y + 1.772 * (cb - 128); return u8(np.stack([r, g, b], -1))

# ----------------------------------------------------------- JPEG-style codec
QL = np.array([[16, 11, 10, 16, 24, 40, 51, 61], [12, 12, 14, 19, 26, 58, 60, 55],
               [14, 13, 16, 24, 40, 57, 69, 56], [14, 17, 22, 29, 51, 87, 80, 62],
               [18, 22, 37, 56, 68, 109, 103, 77], [24, 35, 55, 64, 81, 104, 113, 92],
               [49, 64, 78, 87, 103, 121, 120, 101], [72, 92, 95, 98, 112, 100, 103, 99]], float)
QC = np.full((8, 8), 99.0)
QC[:4, :4] = [[17, 18, 24, 47], [18, 21, 26, 66], [24, 26, 56, 99], [47, 66, 99, 99]]
QC[:4, 4:] = 99; QC[4:, :4] = 99

def scaled_q(T, q):
    s = 5000 / q if q < 50 else 200 - 2 * q
    return np.clip(np.floor((T * s + 50) / 100), 1, 255)

def dct_matrix(n=8):
    C = np.zeros((n, n))
    for k in range(n):
        for i in range(n):
            C[k, i] = np.sqrt((1 if k == 0 else 2) / n) * np.cos((2 * i + 1) * k * np.pi / (2 * n))
    return C
C8 = dct_matrix()

def to_blocks(a):
    h, w = a.shape
    return a.reshape(h // 8, 8, w // 8, 8).transpose(0, 2, 1, 3).reshape(-1, 8, 8)

def from_blocks(b, h, w):
    return b.reshape(h // 8, w // 8, 8, 8).transpose(0, 2, 1, 3).reshape(h, w)

def zigzag_order(n=8):
    pts = sorted(((i, j) for i in range(n) for j in range(n)),
                 key=lambda p: (p[0] + p[1], p[1] if (p[0] + p[1]) % 2 == 0 else p[0]))
    return np.array([i * n + j for i, j in pts])
ZZ = zigzag_order(); ZZ_INV = np.argsort(ZZ)

def bitlen(v): return int(abs(int(v))).bit_length()

def block_symbols(zz):
    """zz: (nb,64) zigzag blocks -> DC and AC symbol lists [(symbol, value, nbits)]."""
    dc, ac, prev = [], [], 0
    for b in zz:
        d = int(b[0]) - prev; prev = int(b[0]); s = bitlen(d); dc.append((s, d, s)); run = 0
        for k in range(1, 64):
            v = int(b[k])
            if v == 0: run += 1; continue
            while run > 15: ac.append(((15, 0), 0, 0)); run -= 16
            s = bitlen(v); ac.append(((run, s), v, s)); run = 0
        if run > 0: ac.append(((0, 0), 0, 0))
    return dc, ac

def huffman_lengths(freq):
    if len(freq) == 1: return {next(iter(freq)): 1}
    heap = [(f, i, [s]) for i, (s, f) in enumerate(sorted(freq.items(), key=lambda t: str(t[0])))]
    heapq.heapify(heap); depth = {s: 0 for s in freq}; cnt = len(heap)
    while len(heap) > 1:
        f1, _, s1 = heapq.heappop(heap); f2, _, s2 = heapq.heappop(heap)
        for s in s1 + s2: depth[s] += 1
        heapq.heappush(heap, (f1 + f2, cnt, s1 + s2)); cnt += 1
    return depth

def canonical_codes(lengths):
    code, prev, out = 0, 0, {}
    for s, l in sorted(lengths.items(), key=lambda t: (t[1], str(t[0]))):
        code <<= (l - prev); out[s] = format(code, '0%db' % l); code += 1; prev = l
    return out

def amp_bits(v, s):
    if s == 0: return ''
    return format(v if v >= 0 else v + (1 << s) - 1, '0%db' % s)

def encode_stream(syms, codes):
    return ''.join(codes[s] + amp_bits(v, n) for s, v, n in syms)

def decode_stream(bits, codes, count):
    inv = {c: s for s, c in codes.items()}; out, i, cur = [], 0, ''
    while len(out) < count:
        cur += bits[i]; i += 1
        if cur in inv:
            s = inv[cur]; n = s if isinstance(s, int) else s[1]
            if n:
                val = int(bits[i:i + n], 2); i += n
                if val < (1 << (n - 1)): val -= (1 << n) - 1
            else: val = 0
            out.append((s, val, n)); cur = ''
    return out

def _table_cost(lengths):  # JPEG DHT segment: 16 count bytes + 1 byte per symbol (+ marker bytes)
    return 8 * (16 + len(lengths) + 5)

def codec(img, q, subsample=True, verify=False):
    """Encode+decode a gray (H,W) or RGB (H,W,3) uint8 image. Returns dict."""
    gray = img.ndim == 2
    if gray: comps = [(img.astype(float), QL, 'L')]
    else:
        y, cb, cr = rgb2ycbcr(img)
        if subsample:
            cb = cb.reshape(cb.shape[0] // 2, 2, cb.shape[1] // 2, 2).mean((1, 3))
            cr = cr.reshape(cr.shape[0] // 2, 2, cr.shape[1] // 2, 2).mean((1, 3))
        comps = [(y, QL, 'L'), (cb, QC, 'C'), (cr, QC, 'C')]
    tables = {'DCL': Counter(), 'ACL': Counter(), 'DCC': Counter(), 'ACC': Counter()}
    streams, rec = [], []
    for plane, T, kind in comps:
        Q = scaled_q(T, q); h, w = plane.shape
        F = C8 @ to_blocks(plane - 128) @ C8.T
        qc = np.rint(F / Q).astype(int)
        zz = qc.reshape(-1, 64)[:, ZZ]
        dc, ac = block_symbols(zz)
        tables['DC' + kind].update(s for s, _, _ in dc); tables['AC' + kind].update(s for s, _, _ in ac)
        streams.append((kind, dc, ac, zz))
        deq = (qc * Q); rec.append(from_blocks(C8.T @ deq @ C8, h, w) + 128)
    lens = {k: huffman_lengths(v) for k, v in tables.items() if v}
    codes = {k: canonical_codes(v) for k, v in lens.items()}
    payload = 0
    for kind, dc, ac, _ in streams:
        for s, _, n in dc: payload += lens['DC' + kind][s] + n
        for s, _, n in ac: payload += lens['AC' + kind][s] + n
    header = 8 * (2 * 64 + 25) + sum(_table_cost(l) for l in lens.values()) if not gray else \
        8 * (64 + 20) + sum(_table_cost(l) for l in lens.values())
    bits = payload + header
    lossless_ok = None
    if verify:
        lossless_ok = True
        for kind, dc, ac, zz in streams:
            for name, syms in (('DC' + kind, dc), ('AC' + kind, ac)):
                bs = encode_stream(syms, codes[name])
                if decode_stream(bs, codes[name], len(syms)) != syms: lossless_ok = False
    if gray: out = u8(rec[0])
    else:
        yy = rec[0]; cb2, cr2 = rec[1], rec[2]
        if subsample: cb2 = ndi.zoom(cb2, 2, order=1); cr2 = ndi.zoom(cr2, 2, order=1)
        out = ycbcr2rgb(yy, cb2, cr2)
    raw = img.size * 8
    return dict(recon=out, bits=bits, payload=payload, header=header, ratio=raw / bits,
                bpp=bits / (img.shape[0] * img.shape[1]), psnr=psnr(img, out), ssim=ssim(img, out),
                lossless_ok=lossless_ok, nsyms={k: len(v) for k, v in lens.items()})

def pillow_jpeg(img, q, optimize=False, subsampling=2):
    buf = io.BytesIO(); im = Image.fromarray(img)
    kw = dict(quality=q, optimize=optimize)
    if img.ndim == 3: kw['subsampling'] = subsampling
    im.save(buf, 'JPEG', **kw); n = buf.tell(); buf.seek(0)
    dec = np.array(Image.open(buf))
    return dict(recon=dec, bits=8 * n, ratio=img.size * 8 / (8 * n), bpp=8 * n / (img.shape[0] * img.shape[1]),
                psnr=psnr(img, dec), ssim=ssim(img, dec))

# ----------------------------------------------- morphology / segmentation
def otsu(img):
    p = np.bincount(img.ravel(), minlength=256).astype(float); p /= p.sum()
    w = p.cumsum(); m = (p * np.arange(256)).cumsum(); mt = m[-1]
    with np.errstate(divide='ignore', invalid='ignore'):
        sb = (mt * w - m) ** 2 / (w * (1 - w))
    return int(np.nanargmax(sb))

def _shifts(m):
    p = np.pad(m, 1); H, W = m.shape
    return [p[i:i + H, j:j + W] for i in range(3) for j in range(3)]

def dilate(m): return np.any(_shifts(m), axis=0)
def erode(m): return np.all(_shifts(m), axis=0)
def opening(m): return dilate(erode(m))
def closing(m): return erode(dilate(m))

def region_grow(img, seed, tol):
    H, W = img.shape; out = np.zeros(img.shape, bool); v0 = float(img[seed]); dq = deque([seed]); out[seed] = True
    while dq:
        r, c = dq.popleft()
        for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            rr, cc = r + dr, c + dc
            if 0 <= rr < H and 0 <= cc < W and not out[rr, cc] and abs(float(img[rr, cc]) - v0) <= tol:
                out[rr, cc] = True; dq.append((rr, cc))
    return out

SOBEL_X = np.array([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], float)
PREWITT_X = np.array([[-1, 0, 1], [-1, 0, 1], [-1, 0, 1]], float)
def gradient_mag(img, kx):
    gx = conv2d(img, kx); gy = conv2d(img, kx.T); return np.hypot(gx, gy)
